package com.ericdaugherty.itunesexport

/**
 * Current version of this application
 *
 * @author Eric Daugherty
 */
trait Version {
  val version = "2.2.2"
}